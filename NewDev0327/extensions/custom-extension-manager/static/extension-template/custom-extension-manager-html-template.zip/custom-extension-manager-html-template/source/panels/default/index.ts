import { readFileSync } from 'fs';
import { join } from 'path';
import { showLog, showWarn, showError, waitTime } from '../../Utils';
import * as CoreService from '../../CoreService';

module.exports = Editor.Panel.define({
    listeners: {
        // show() { console.log('show'); },
        // hide() { console.log('hide'); },
    },
    template: readFileSync(join(__dirname, '../../../static/template/default/index.html'), 'utf-8'),
    style: readFileSync(join(__dirname, '../../../static/style/default/index.css'), 'utf-8'),
    $: {
        exampleButton1: '#example-button1',
        exampleButton2: '#example-button2',
        exampleText: '#example-text',
    },
    methods: {
        onExampleButtonClick() {
            showLog('Hello');
        },
        onExampleButton2Click() {
            const random = CoreService.getRandomNumber();
            (this.$.exampleText as HTMLParagraphElement).textContent = `文字區塊數字: ${random}`;
        },

        // 綁定事件處理函數並保存引用
        boundOnExampleButton1Click: null as any,
        boundOnExampleButton2Click: null as any,
    },
    ready() {
        // 保存綁定後的函數引用
        this.boundOnExampleButton1Click = this.onExampleButtonClick.bind(this);
        this.boundOnExampleButton2Click = this.onExampleButton2Click.bind(this);

        (this.$.exampleButton1 as HTMLButtonElement).addEventListener('click', this.boundOnExampleButton1Click);
        (this.$.exampleButton2 as HTMLButtonElement).addEventListener('click', this.boundOnExampleButton2Click);
    },
    beforeClose() { },
    close() {
        (this.$.exampleButton1 as HTMLButtonElement).removeEventListener('click', this.boundOnExampleButton1Click);
        (this.$.exampleButton2 as HTMLButtonElement).removeEventListener('click', this.boundOnExampleButton2Click);
    },
});
