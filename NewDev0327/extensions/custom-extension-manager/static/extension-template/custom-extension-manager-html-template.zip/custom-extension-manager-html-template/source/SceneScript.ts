/**
 * 若插件功能需要與 cc API 互動，請依照以下步驟進行:
 * 1.在外部透過 Editor API 呼叫 SceneScript
 * const functionResult = await Editor.Message.request('scene', 'execute-scene-script', {
 *     name: packageJSON.name,
 *     method: 'mySceneFunction', // 必須對應到 SceneScript.ts 中的 methods
 *     args: <傳入必要的參數>,
 * });
 *
 * 2.在 SceneScript.ts 中實作 mySceneFunction 方法，並視需要將執行結果回傳，由 functionResult 接收
 */

// import { join } from 'path';
// module.paths.push(join(Editor.App.path, 'node_modules'));
// import { Component, director, Node } from "cc";

// export const methods: { [key: string]: (...any: any) => any } = {
//     mySceneFunction() {
//         // 在這裡實作會和場景交互的方法
//         // 可以像寫遊戲腳本一樣直接調用 cc 的 API
//     },
// };